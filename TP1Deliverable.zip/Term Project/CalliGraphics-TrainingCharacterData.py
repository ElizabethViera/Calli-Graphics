#Elizabeth Viera
#Training Character Data
from Calligraphics-TrainingCharacterClass.py import TrainingCharacter